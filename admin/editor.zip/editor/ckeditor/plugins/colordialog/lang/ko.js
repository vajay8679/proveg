﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ko', {
	clear: '제거',
	highlight: '하이라이트',
	options: '색상 옵션',
	selected: '색상 선택됨',
	title: '색상 선택'
} );
