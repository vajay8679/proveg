﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'gl', {
	clear: 'Limpar',
	highlight: 'Resaltar',
	options: 'Opcións de cor',
	selected: 'Cor seleccionado',
	title: 'Seleccione unha cor'
} );
