﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'id', {
	fontSize: {
		label: 'Ukuran',
		voiceLabel: 'Font Size', // MISSING
		panelTitle: 'Font Size' // MISSING
	},
	label: 'Font', // MISSING
	panelTitle: 'Font Name', // MISSING
	voiceLabel: 'Font' // MISSING
} );
